package com.jobportal.jobportal.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jobportal.jobportal.Exception.UserAlreadyExixtsException;
import com.jobportal.jobportal.Model.User;
import com.jobportal.jobportal.Repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;

	public User saveUser(User user) {
		Optional<User> isUserAlreadyExists = userRepository.findByEmail(user.getEmail());
		if (isUserAlreadyExists.isPresent()) {
			throw new UserAlreadyExixtsException("User with this email is already exixts!!!");
		} else {
			user.setPassword(passwordEncoder.encode(user.getPassword()));
			user.setConfirmPassword(passwordEncoder.encode(user.getConfirmPassword()));

			return userRepository.save(user);
		}

	}

	public Optional<User> getParticularUser(String users) {
		Optional<User> oldUser = userRepository.findByEmail(users);
		return oldUser;
	}

}
