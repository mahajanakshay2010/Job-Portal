package com.jobportal.jobportal.Exception;

public class UserDoesNotExistsException extends RuntimeException {
	public UserDoesNotExistsException(String msg) {
		super(msg);
	}
}
