package com.jobportal.jobportal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobportal.jobportal.Model.JobRequest;
import com.jobportal.jobportal.Model.JobResponse;
import com.jobportal.jobportal.Service.JobRequestService;
import com.jobportal.jobportal.Service.JobResponseService;

@RestController
@RequestMapping("/job")
public class JobController {
	@Autowired
	private JobRequestService jobRequestService;
	@Autowired
	private JobResponseService jobResponseService;

	@PostMapping("/create")
	public ResponseEntity<String> createJob(@RequestBody JobRequest jobRequest) {
		try {
			String response = jobRequestService.createJob(jobRequest);
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (IllegalArgumentException e) {
			return new ResponseEntity<>("Invalid job request.", HttpStatus.BAD_REQUEST);
		} catch (DataAccessException e) {
			return new ResponseEntity<>("Database access error.", HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			return new ResponseEntity<>("An unexpected error occurred.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/apply")
	public ResponseEntity<String> apply(@RequestBody JobResponse jobResponse) {
		try {
			String response = jobResponseService.applyJob(jobResponse);
			if (response.equals("Your response Already Submitted")) {
				return new ResponseEntity<>("Invalid job request, " + response, HttpStatus.BAD_REQUEST);
			}
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (IllegalArgumentException e) {
			return new ResponseEntity<>("Invalid job response.", HttpStatus.BAD_REQUEST);
		} catch (DataAccessException e) {
			return new ResponseEntity<>("Database access error.", HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			return new ResponseEntity<>("An unexpected error occurred.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/Jobs")
	public ResponseEntity<List<JobRequest>> getAllJobs() {
		try {
			List<JobRequest> allJobs = jobRequestService.getJobs();
			return new ResponseEntity<>(allJobs, HttpStatus.OK);
		} catch (DataAccessException e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}