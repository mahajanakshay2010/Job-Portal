package com.jobportal.jobportal.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jobportal.jobportal.Model.JobResponse;
import com.jobportal.jobportal.Repository.JobResponseRepository;

@Service
public class JobResponseService {
	@Autowired
	private JobResponseRepository jobResponseRepository;

	public String applyJob(JobResponse jobResponse) {
		String response;
		try {
			Optional<JobResponse> isApplied = jobResponseRepository.findByEmailAndJob(jobResponse.getJobId().getJobId(),
					jobResponse.getEmail());
			if (isApplied.isEmpty()) {
				jobResponseRepository.save(jobResponse);
				response = "Applied for Job Successfully.";

			} else {
				response = "Your response Already Submitted";
			}

		} catch (DataAccessException e) {
			response = "Error applying for job: Database access error.";
		} catch (IllegalArgumentException e) {
			response = "Error applying for job: Invalid job response.";
		} catch (Exception e) {
			response = "Error applying for job: An unexpected error occurred.";
		}
		return response;
	}
}