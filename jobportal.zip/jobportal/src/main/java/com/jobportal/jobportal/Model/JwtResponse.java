package com.jobportal.jobportal.Model;

public class JwtResponse {
	private String userName;
	private String response;
	private String role;
	private String tokenString;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTokenString() {
		return tokenString;
	}

	public void setTokenString(String tokenString) {
		this.tokenString = tokenString;
	}

	public JwtResponse(String userName, String response, String role, String tokenString) {
		super();
		this.userName = userName;
		this.response = response;
		this.role = role;
		this.tokenString = tokenString;
	}

	public JwtResponse() {
		super();
	}

}
