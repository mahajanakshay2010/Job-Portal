package com.jobportal.jobportal.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jobportal.jobportal.Model.JobResponse;

@Repository
public interface JobResponseRepository extends JpaRepository<JobResponse, Integer> {

	@Query(value = "SELECT * FROM job_response WHERE job_id = :jobId AND email = :email", nativeQuery = true)
	Optional<JobResponse> findByEmailAndJob(@Param("jobId") int jobId, @Param("email") String email);
}
