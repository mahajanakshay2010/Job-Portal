package com.jobportal.jobportal.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import com.jobportal.jobportal.Model.JobRequest;
import com.jobportal.jobportal.Repository.JobRequestRepository;

@Service
public class JobRequestService {
	@Autowired
	private JobRequestRepository jobRequestRepository;

	public String createJob(JobRequest jobRequest) {
		String responseString;
		try {
			JobRequest jobRequest2 = jobRequestRepository.save(jobRequest);
			responseString = "Job created successfully with Title: " + jobRequest2.getJobTitle();
		} catch (DataAccessException e) {
			responseString = "Error creating job: Database access error.";
		} catch (IllegalArgumentException e) {
			responseString = "Error creating job: Invalid job request.";
		} catch (Exception e) {
			responseString = "Error creating job: An unexpected error occurred.";
		}
		return responseString;
	}

	public List<JobRequest> getJobs() {
		try {
			return jobRequestRepository.findAll();
		} catch (DataAccessException e) {

			throw new RuntimeException("Database access error while retrieving jobs.", e);
		} catch (Exception e) {

			throw new RuntimeException("An unexpected error occurred while retrieving jobs.", e);
		}
	}
}