package com.jobportal.jobportal.Model;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;

@Entity
public class JobResponse {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int jobResponseId;
	@ManyToOne
	@JoinColumn(name = "jobId")
	private JobRequest jobId;
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private String degree;
	private String course;
	private Date startDate;
	private Date endDate;
	@Lob
	private byte[] resume;
	
	

	public int getJobResponseId() {
		return jobResponseId;
	}

	public void setJobResponseId(int jobResponseId) {
		this.jobResponseId = jobResponseId;
	}

	public JobRequest getJobId() {
		return jobId;
	}

	public void setJobId(JobRequest jobId) {
		this.jobId = jobId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public byte[] getResume() {
		return resume;
	}

	public void setResume(byte[] resume) {
		this.resume = resume;
	}

	public JobResponse(String firstName, String lastName, String email, String phoneNumber, String degree,
			String course, Date startDate, Date endDate, byte[] resume) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.degree = degree;
		this.course = course;
		this.startDate = startDate;
		this.endDate = endDate;
		this.resume = resume;
	}

	public JobResponse() {
		super();
	}

}
