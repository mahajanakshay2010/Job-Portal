package com.jobportal.jobportal.Exception;

public class UserAlreadyExixtsException extends RuntimeException {
	public UserAlreadyExixtsException(String msg) {
		super();
	}
}
